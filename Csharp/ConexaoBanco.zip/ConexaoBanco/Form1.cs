namespace ConexaoBanco
{
    using System.Data;
    using MySql;
    using MySql.Data;
    using MySql.Data.MySqlClient;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private MySqlConnection mConn;
        private MySqlDataAdapter mAdapter;
        private DataSet mDataset;


        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (EditNome.Text != "" && EditEmail.Text != "" ) {

                Conectar();
                //Query SQL
                MySqlCommand command = new MySqlCommand("INSERT INTO contatos (nome,email)"
                + "VALUES('" + EditNome.Text + "','" + EditEmail.Text + "')", mConn);
                //Executa a Query SQL
                command.ExecuteNonQuery();
                //Mensagem de Sucesso
                MessageBox.Show("Gravado com Sucesso!", "Informa��o",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                mostrarResultados();
                limpar();
            }
            else{
                MessageBox.Show("N�o � possivel inserir valores em Branco!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void Conectar()
        {
            mDataset = new DataSet(); //Define Dataset 

            mConn = new MySqlConnection("Persist Security Info=False; server=localhost; port=3306; database=cadastros; uid=root; pwd=root");

            try
            {
                //Abre conex�o
                mConn.Open();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void mostrarResultados()
        {
            if (mConn.State == ConnectionState.Open)
            {
                // Cria um adaptador usando a instru��o Sql 
                mAdapter = new MySqlDataAdapter("SELECT ID, NOME, EMAIL FROM CONTATOS;", mConn);
                // Preenche o dataset via adapter 
                mAdapter.Fill(mDataset, "Contatos"); // Corrigido para "Contatos"
                                                     // Atribui a resultado
                dgvDados.DataSource = mDataset;
                dgvDados.DataMember = "Contatos";
                mConn.Close();
            }
        }


        private void limpar()
        {
            EditEmail.Text = "";
            EditNome.Text = "";
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            limpar();
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Conectar();
            mostrarResultados();
            limpar();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {

        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            if (dgvDados.CurrentRow != null)
            {
                string valor_id = dgvDados.CurrentRow.Cells["id"].Value?.ToString();

                if (!string.IsNullOrEmpty(valor_id))
                {
                    Conectar();
                    MySqlCommand command = new MySqlCommand("DELETE FROM contatos WHERE id = '" + valor_id + "';", mConn);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Registro Exclu�do com Sucesso!");
                    mostrarResultados();
                    limpar();
                }
                else
                {
                    MessageBox.Show("Para excluir, selecione um registro!", "Aten��o",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Nenhuma linha selecionada.", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (dgvDados.CurrentRow != null)
            {
                string valor_id = dgvDados.CurrentRow.Cells["id"].Value?.ToString();

                if (!string.IsNullOrEmpty(valor_id))
                {
                    string sql = "UPDATE contatos SET nome = '" + EditNome.Text + "', email = '" +
                                 EditEmail.Text + "' WHERE id = " + valor_id + ";";
                    if (valor_id != string.Empty)
                    {
                        Conectar();
                        MySqlCommand command = new MySqlCommand(sql, mConn);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Registro Alterado com Sucesso!");
                        mostrarResultados();
                        limpar();
                    }
                    else
                    {
                        MessageBox.Show("Para excluir, selecione um registro!", "Aten��o",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("Nenhuma linha selecionada.", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvDados_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string id = this.dgvDados.CurrentRow.Cells["id"].Value.ToString();
            if (id != null)
            {
                this.EditNome.Text = Convert.ToString(this.dgvDados.CurrentRow.Cells["nome"].Value);
                this.EditEmail.Text = Convert.ToString(this.dgvDados.CurrentRow.Cells["email"].Value);
            }
        }
    }
}
