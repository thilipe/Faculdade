﻿namespace FormularioMDI
{
    partial class FormMediaPessoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridMedia = new System.Windows.Forms.DataGridView();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Filhos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.labelResult = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelFilho = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelMaior = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMedia)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridMedia
            // 
            this.dataGridMedia.AllowUserToAddRows = false;
            this.dataGridMedia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridMedia.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nome,
            this.Salario,
            this.Filhos});
            this.dataGridMedia.Location = new System.Drawing.Point(12, 11);
            this.dataGridMedia.Name = "dataGridMedia";
            this.dataGridMedia.RowTemplate.Height = 25;
            this.dataGridMedia.Size = new System.Drawing.Size(343, 328);
            this.dataGridMedia.TabIndex = 0;
            // 
            // Nome
            // 
            this.Nome.HeaderText = "Nome";
            this.Nome.Name = "Nome";
            // 
            // Salario
            // 
            this.Salario.HeaderText = "Salário";
            this.Salario.Name = "Salario";
            // 
            // Filhos
            // 
            this.Filhos.HeaderText = "Filhos";
            this.Filhos.Name = "Filhos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(361, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Média dos salários informados:";
            // 
            // labelResult
            // 
            this.labelResult.BackColor = System.Drawing.Color.Yellow;
            this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelResult.Location = new System.Drawing.Point(539, 13);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(91, 25);
            this.labelResult.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(361, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Média do número de filhos:";
            // 
            // labelFilho
            // 
            this.labelFilho.BackColor = System.Drawing.Color.Yellow;
            this.labelFilho.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelFilho.Location = new System.Drawing.Point(539, 47);
            this.labelFilho.Name = "labelFilho";
            this.labelFilho.Size = new System.Drawing.Size(91, 25);
            this.labelFilho.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(361, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Maior salário dos habitantes:";
            // 
            // labelMaior
            // 
            this.labelMaior.BackColor = System.Drawing.Color.Yellow;
            this.labelMaior.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelMaior.Location = new System.Drawing.Point(539, 80);
            this.labelMaior.Name = "labelMaior";
            this.labelMaior.Size = new System.Drawing.Size(91, 25);
            this.labelMaior.TabIndex = 1;
            // 
            // btnResultado
            // 
            this.btnResultado.Location = new System.Drawing.Point(361, 135);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(108, 23);
            this.btnResultado.TabIndex = 2;
            this.btnResultado.Text = "Resultado";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // FormMediaPessoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 351);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.labelMaior);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelFilho);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridMedia);
            this.Name = "FormMediaPessoa";
            this.Text = "FormMediaPessoa";
            this.Load += new System.EventHandler(this.FormMediaPessoa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMedia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridMedia;
        private Label label1;
        private Label labelResult;
        private Label label2;
        private Label labelFilho;
        private Label label4;
        private Label labelMaior;
        private Button btnResultado;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn Salario;
        private DataGridViewTextBoxColumn Filhos;
    }
}