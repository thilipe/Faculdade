﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMDI
{
    public partial class FormIdade : Form
    {
        public FormIdade()
        {
            InitializeComponent();
        }

       

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
             if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
                {
                    e.Handled = true;
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int valor = Int32.Parse(textBox1.Text);
            valor = valor * 365;
            labelResult.Text = valor.ToString() + " Dias";
        }
    }
}
