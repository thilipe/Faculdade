namespace FormularioMDI
{
    public partial class FormularioMDI : Form
    {
        public FormularioMDI()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormIdade frmEditorTexto = new FormIdade();

            frmEditorTexto.MdiParent = this;

            frmEditorTexto.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMediaPessoa frmEditorTexto = new FormMediaPessoa();

            frmEditorTexto.MdiParent = this;

            frmEditorTexto.Show();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormularioNotas frmEditorTexto = new FormularioNotas();

            frmEditorTexto.MdiParent = this;

            frmEditorTexto.Show();
        }
    }
}