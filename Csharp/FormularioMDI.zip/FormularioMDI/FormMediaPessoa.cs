﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMDI
{
    public partial class FormMediaPessoa : Form
    {
        public FormMediaPessoa()
        {
            InitializeComponent();
        }

        private void FormMediaPessoa_Load(object sender, EventArgs e)
        {
            dataGridMedia.RowCount = 20;
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            double mediaSalario = 0;
            double maiorSalario = 0;
            double salario = 0;
            int mediafilhos = 0, countSalario = 0, countFilhos = 0;
            object verificar;

            foreach (DataGridViewRow dataGridViewRow in dataGridMedia.Rows)
            {
                verificar = dataGridViewRow.Cells["Salario"].Value;
                if (verificar != null && !string.IsNullOrEmpty(verificar.ToString()))
                {
                    countSalario += 1;
                    mediaSalario += Convert.ToDouble(dataGridViewRow.Cells["Salario"].Value.ToString());
                    salario = Convert.ToDouble(dataGridViewRow.Cells["Salario"].Value.ToString());
                    if(maiorSalario <= salario) { maiorSalario = salario; 
                    }
                }
                verificar = dataGridViewRow.Cells["Filhos"].Value;
                if (verificar != null && !string.IsNullOrEmpty(verificar.ToString()))
                {
                    countFilhos += 1;
                    mediafilhos += Int32.Parse(dataGridViewRow.Cells["Filhos"].Value.ToString());
                }
            }

            mediaSalario = mediaSalario / countSalario;
            mediafilhos = mediafilhos / countFilhos;
            labelResult.Text = mediaSalario.ToString();
            labelFilho.Text = mediafilhos.ToString();
            labelMaior.Text = maiorSalario.ToString();
        }
    }
}
