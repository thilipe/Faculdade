﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormularioMDI
{
    public partial class FormularioNotas : Form
    {
        public FormularioNotas()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            double mediaClasse = 0, nota1 = 0, nota2 = 0, nota = 0;
            int qtdApr = 0, qtdRep = 0, qtdExa = 0, CountMedia = 0;
            object verificar;

            foreach (DataGridViewRow dataGridViewRow in GridAlunos.Rows)
            {
                nota1 = 0; nota2 = 0;

                verificar = dataGridViewRow.Cells["nota1"].Value;
                if (verificar != null && !string.IsNullOrEmpty(verificar.ToString()))
                {
                    nota1 += Convert.ToDouble(dataGridViewRow.Cells["nota1"].Value.ToString());
                }

                verificar = dataGridViewRow.Cells["nota2"].Value;
                if (verificar != null && !string.IsNullOrEmpty(verificar.ToString()))
                {
                    nota2 += Convert.ToDouble(dataGridViewRow.Cells["nota2"].Value.ToString());
                }
                if (nota1 != 0 || nota2 != 0)
                {
                    //Media é 6, para ficar de exame é até 1, 0 é reprovado
                    CountMedia += 1;
                    nota = nota1 + nota2;
                    mediaClasse += nota;
                    if (nota >= 6)
                    {
                        qtdApr += 1;
                    }
                    else if (nota != 0 && nota < 6)
                    {
                        qtdExa += 1;
                    }
                    else { qtdRep += 1; }
                }
            }
            mediaClasse = mediaClasse / CountMedia;
            labelAprovado.Text = qtdApr.ToString();
            labelExame.Text = qtdExa.ToString();
            labelReprovado.Text = qtdRep.ToString();
            labelMedia.Text = mediaClasse.ToString();


        }

        private void FormularioNotas_Load(object sender, EventArgs e)
        {
            GridAlunos.RowCount = 10;
        }
    }
}
