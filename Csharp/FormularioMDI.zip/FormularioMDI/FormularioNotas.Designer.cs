﻿namespace FormularioMDI
{
    partial class FormularioNotas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnResultado = new Button();
            labelExame = new Label();
            label4 = new Label();
            labelAprovado = new Label();
            label2 = new Label();
            labelMedia = new Label();
            labelClasse = new Label();
            GridAlunos = new DataGridView();
            Nome = new DataGridViewTextBoxColumn();
            Nota1 = new DataGridViewTextBoxColumn();
            Nota2 = new DataGridViewTextBoxColumn();
            label1 = new Label();
            labelReprovado = new Label();
            ((System.ComponentModel.ISupportInitialize)GridAlunos).BeginInit();
            SuspendLayout();
            // 
            // btnResultado
            // 
            btnResultado.Location = new Point(446, 192);
            btnResultado.Margin = new Padding(3, 4, 3, 4);
            btnResultado.Name = "btnResultado";
            btnResultado.Size = new Size(123, 31);
            btnResultado.TabIndex = 10;
            btnResultado.Text = "Resultado";
            btnResultado.UseVisualStyleBackColor = true;
            btnResultado.Click += btnResultado_Click;
            // 
            // labelExame
            // 
            labelExame.BackColor = Color.Yellow;
            labelExame.BorderStyle = BorderStyle.Fixed3D;
            labelExame.Location = new Point(691, 99);
            labelExame.Name = "labelExame";
            labelExame.Size = new Size(104, 33);
            labelExame.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(446, 107);
            label4.Name = "label4";
            label4.Size = new Size(237, 20);
            label4.TabIndex = 5;
            label4.Text = "Quantidade de alunos de exames: ";
            // 
            // labelAprovado
            // 
            labelAprovado.BackColor = Color.Yellow;
            labelAprovado.BorderStyle = BorderStyle.Fixed3D;
            labelAprovado.Location = new Point(644, 55);
            labelAprovado.Name = "labelAprovado";
            labelAprovado.Size = new Size(104, 33);
            labelAprovado.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(446, 63);
            label2.Name = "label2";
            label2.Size = new Size(189, 20);
            label2.TabIndex = 7;
            label2.Text = "Quantidade de aprovados: ";
            // 
            // labelMedia
            // 
            labelMedia.BackColor = Color.Yellow;
            labelMedia.BorderStyle = BorderStyle.Fixed3D;
            labelMedia.Location = new Point(574, 9);
            labelMedia.Name = "labelMedia";
            labelMedia.Size = new Size(104, 33);
            labelMedia.TabIndex = 8;
            // 
            // labelClasse
            // 
            labelClasse.AutoSize = true;
            labelClasse.Location = new Point(446, 17);
            labelClasse.Name = "labelClasse";
            labelClasse.Size = new Size(122, 20);
            labelClasse.TabIndex = 9;
            labelClasse.Text = "Média da classe: ";
            // 
            // GridAlunos
            // 
            GridAlunos.AllowUserToAddRows = false;
            GridAlunos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            GridAlunos.Columns.AddRange(new DataGridViewColumn[] { Nome, Nota1, Nota2 });
            GridAlunos.Location = new Point(47, 7);
            GridAlunos.Margin = new Padding(3, 4, 3, 4);
            GridAlunos.Name = "GridAlunos";
            GridAlunos.RowHeadersWidth = 51;
            GridAlunos.RowTemplate.Height = 25;
            GridAlunos.Size = new Size(392, 437);
            GridAlunos.TabIndex = 3;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 6;
            Nome.Name = "Nome";
            Nome.Width = 125;
            // 
            // Nota1
            // 
            Nota1.HeaderText = "Nota 1";
            Nota1.MinimumWidth = 6;
            Nota1.Name = "Nota1";
            Nota1.Width = 125;
            // 
            // Nota2
            // 
            Nota2.HeaderText = "Nota 2";
            Nota2.MinimumWidth = 6;
            Nota2.Name = "Nota2";
            Nota2.Width = 125;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(446, 154);
            label1.Name = "label1";
            label1.Size = new Size(194, 20);
            label1.TabIndex = 5;
            label1.Text = "Quantidade de reprovados: ";
            // 
            // labelReprovado
            // 
            labelReprovado.BackColor = Color.Yellow;
            labelReprovado.BorderStyle = BorderStyle.Fixed3D;
            labelReprovado.Location = new Point(646, 147);
            labelReprovado.Name = "labelReprovado";
            labelReprovado.Size = new Size(104, 33);
            labelReprovado.TabIndex = 4;
            // 
            // FormularioNotas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(827, 450);
            Controls.Add(btnResultado);
            Controls.Add(labelReprovado);
            Controls.Add(labelExame);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(labelAprovado);
            Controls.Add(label2);
            Controls.Add(labelMedia);
            Controls.Add(labelClasse);
            Controls.Add(GridAlunos);
            Name = "FormularioNotas";
            Text = "FormularioNotas";
            Load += FormularioNotas_Load;
            ((System.ComponentModel.ISupportInitialize)GridAlunos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnResultado;
        private Label labelExame;
        private Label label4;
        private Label labelAprovado;
        private Label label2;
        private Label labelMedia;
        private Label labelClasse;
        private DataGridView GridAlunos;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn Nota1;
        private DataGridViewTextBoxColumn Nota2;
        private Label label1;
        private Label labelReprovado;
    }
}