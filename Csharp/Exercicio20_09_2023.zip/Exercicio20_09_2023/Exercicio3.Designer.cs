﻿namespace Exercicio20_09_2023
{
    partial class Exercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.n1 = new System.Windows.Forms.TextBox();
            this.n2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ResultadoConta = new System.Windows.Forms.Label();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Digite um Número:";
            // 
            // n1
            // 
            this.n1.Location = new System.Drawing.Point(127, 19);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(69, 23);
            this.n1.TabIndex = 2;
            this.n1.TextChanged += new System.EventHandler(this.n1_TextChanged);
            this.n1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.n1_KeyPress);
            // 
            // n2
            // 
            this.n2.Location = new System.Drawing.Point(322, 19);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(69, 23);
            this.n2.TabIndex = 2;
            this.n2.TextChanged += new System.EventHandler(this.n2_TextChanged);
            this.n2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.n2_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Digite um Número:";
            // 
            // ResultadoConta
            // 
            this.ResultadoConta.BackColor = System.Drawing.Color.Yellow;
            this.ResultadoConta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ResultadoConta.Location = new System.Drawing.Point(15, 64);
            this.ResultadoConta.Name = "ResultadoConta";
            this.ResultadoConta.Size = new System.Drawing.Size(376, 38);
            this.ResultadoConta.TabIndex = 4;
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(413, 19);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(121, 23);
            this.comboBox.TabIndex = 5;
            this.comboBox.TextChanged += new System.EventHandler(this.comboBox_TextChanged);
            // 
            // Exercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 111);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.ResultadoConta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Name = "Exercicio3";
            this.Text = "Exercicio3";
            this.Load += new System.EventHandler(this.Exercicio3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox n1;
        private TextBox n2;
        private Label label2;
        private Label ResultadoConta;
        private ComboBox comboBox;
    }
}