namespace Exercicio20_09_2023
{
    public partial class Exercicios : Form
    {
        public Exercicios()
        {
            InitializeComponent();
        }

        private void exercicio1Menu_Click(object sender, EventArgs e)
        {
            Exercicio1 tela = new Exercicio1();
            tela.Show();
        }

        private void exercic�o2Menu_Click(object sender, EventArgs e)
        {
            Exercicio2 tela = new Exercicio2();
            tela.Show();
        }

        private void exercic�o3Menu_Click(object sender, EventArgs e)
        {
            Exercicio3 tela = new Exercicio3();
            tela.Show();
        }
    }
}