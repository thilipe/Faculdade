﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio20_09_2023
{
    public partial class Exercicio3 : Form
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void Exercicio3_Load(object sender, EventArgs e)
        {
            comboBox.Items.Add("Somar");
            comboBox.Items.Add("Subtrair");
            comboBox.Items.Add("Dividir");
            comboBox.Items.Add("Multiplicar");
            
            comboBox.SelectedItem = "Somar";
        }

        private void n2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }

        private void n1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }

        private void Somar()
        {
            double numero1 = 0, numero2 = 0, resultado;
            if (n1.Text != "" && n1.Text != null)
            {
                numero1 = double.Parse(n1.Text);
            }

            if (n2.Text != "" && n2.Text != null)
            {
                numero2 = double.Parse(n2.Text);
            }

            resultado = numero1 + numero2;
            resultado = Math.Round(resultado, 2); // Arredonda para duas casas decimais

            ResultadoConta.Text = resultado.ToString("N2");
        }

        private void subtracao()
        {
            double numero1 = 0, numero2 = 0, resultado;

            if (n1.Text != "" && n1.Text != null)
            {
                numero1 = double.Parse(n1.Text);
            }

            if (n2.Text != "" && n2.Text != null)
            {
                numero2 = double.Parse(n2.Text);
            }

            resultado = numero1 - numero2;
            resultado = Math.Round(resultado, 2); // Arredonda para duas casas decimais

            ResultadoConta.Text = resultado.ToString("N2");
        }

        private void multiplicacao()
        {
            double numero1 = 0, numero2 = 0, resultado;

            if (n1.Text != "" && n1.Text != null)
            {
                numero1 = double.Parse(n1.Text);
            }

            if (n2.Text != "" && n2.Text != null)
            {
                numero2 = double.Parse(n2.Text);
            }

            resultado = numero1 * numero2;
            resultado = Math.Round(resultado, 2); // Arredonda para duas casas decimais

            ResultadoConta.Text = resultado.ToString("N2");
        }

        private void divisao()
        {
            double numero1 = 0, numero2 = 0, resultado;

            if (n1.Text != "" && n1.Text != null)
            {
                numero1 = double.Parse(n1.Text);
            }

            if (n2.Text != "" && n2.Text != null)
            {
                numero2 = double.Parse(n2.Text);
            }

            if (numero2 != 0)
            {
                resultado = numero1 / numero2;
                resultado = Math.Round(resultado, 2); // Arredonda para duas casas decimais

                ResultadoConta.Text = resultado.ToString("N2");
            }
            else { MessageBox.Show("Não é possível dividir por zero."); }
        }

        private void n1_TextChanged(object sender, EventArgs e)
        {
            Veriricar();
            
        }

        private void Veriricar()
        {
            string operacaoSelecionada = comboBox.SelectedItem.ToString();

            switch (operacaoSelecionada)
            {
                case "Somar":
                    Somar();
                    break;
                case "Subtrair":
                    subtracao();
                    break;
                case "Dividir":
                    divisao();
                    break;
                case "Multiplicar":
                    multiplicacao();
                    break;
                default:
                    MessageBox.Show("Operação inválida.");
                    break;
            }

        }

        private void n2_TextChanged(object sender, EventArgs e)
        {
            Veriricar();
        }

        private void comboBox_TextChanged(object sender, EventArgs e)
        {
            Veriricar();
        }
    }
}
